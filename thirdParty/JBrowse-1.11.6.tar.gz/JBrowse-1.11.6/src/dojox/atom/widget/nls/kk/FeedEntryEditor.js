define(
"dojox/atom/widget/nls/kk/FeedEntryEditor", ({
	doNew: "[жаңа]",
	edit: "[өңдеу]",
	save: "[сақтау]",
	cancel: "[болдырмау]"
})
);
