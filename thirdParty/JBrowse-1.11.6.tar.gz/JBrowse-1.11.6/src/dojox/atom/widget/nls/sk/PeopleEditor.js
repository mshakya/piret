define(
"dojox/atom/widget/nls/sk/PeopleEditor", ({
	add: "Pridať",
	addAuthor: "Pridať autora",
	addContributor: "Pridať prispievateľa"
})
);
