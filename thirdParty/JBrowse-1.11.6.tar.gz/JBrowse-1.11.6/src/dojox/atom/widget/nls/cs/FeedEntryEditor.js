define(
"dojox/atom/widget/nls/cs/FeedEntryEditor", ({
	doNew: "[nové]",
	edit: "[upravit]",
	save: "[uložit]",
	cancel: "[storno]"
})
);
