define(
"dojox/atom/widget/nls/ro/FeedEntryViewer", ({
	displayOptions: "[opţiuni de afişare]",
	title: "Titlu",
	authors: "Autori",
	contributors: "Contribuitori",
	id: "ID",
	close: "[închidere]",
	updated: "Actualizat",
	summary: "Sumar",
	content: "Conţinut"
})
);
