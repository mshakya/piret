define(
"dojox/atom/widget/nls/sv/FeedEntryEditor", ({
	doNew: "[nytt]",
	edit: "[redigera]",
	save: "[spara]",
	cancel: "[avbryt]"
})
);
