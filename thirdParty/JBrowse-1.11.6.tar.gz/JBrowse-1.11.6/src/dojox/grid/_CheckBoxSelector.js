define("dojox/grid/_CheckBoxSelector", ["../main", "./_Selector"], function(dojox){
	return dojox.grid._CheckBoxSelector;
});