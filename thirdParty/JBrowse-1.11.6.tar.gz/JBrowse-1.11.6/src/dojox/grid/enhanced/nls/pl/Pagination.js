define(
"dojox/grid/enhanced/nls/pl/Pagination", ({
	"descTemplate": "Od ${2} do ${3} z ${1} ${0}",
	"firstTip": "Pierwsza strona",
	"lastTip": "Ostatnia strona",
	"nextTip": "Następna strona",
	"prevTip": "Poprzednia strona",
	"itemTitle": "elementy",
	"singularItemTitle": "item",
	"pageStepLabelTemplate": "Strona ${0}",
	"pageSizeLabelTemplate": "Liczba elementów na stronę: ${0}",
	"allItemsLabelTemplate": "Wszystkie elementy",
	"gotoButtonTitle": "Przejdź do konkretnej strony",
	"dialogTitle": "Przechodzenie do strony",
	"dialogIndication": "Określ numer strony",
	"pageCountIndication": " (liczba stron: ${0})",
	"dialogConfirm": "Przejdź",
	"dialogCancel": "Anuluj",
	"all": "Wszystko"
})
);
