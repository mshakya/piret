define(
"dojox/grid/enhanced/nls/hu/EnhancedGrid", ({
	singleSort: "Egyszerű rendezés",
	nestedSort: "Beágyazott rendezés",
	ascending: "Kattintson ide a növekvő rendezéshez",
	descending: "Kattintson ide a csökkenő rendezéshez",
	sortingState: "${0} - ${1}",
	unsorted: "Ne rendezze ezt az oszlopot",
	indirectSelectionRadio: "${0} sor, egyetlen kijelölés, választógomb",
	indirectSelectionCheckBox: "${0} sor, több kijelölés, jelölőnégyzet",
	selectAll: "Összes kijelölése"
})
);
