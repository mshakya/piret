define(
"dojox/grid/enhanced/nls/kk/EnhancedGrid", ({
	singleSort: "Бір рет сұрыптау",
	nestedSort: "Кірістірілген сұрыптау",
	ascending: "Артуы бойынша сұрыптауды басу",
	descending: "Кемуі бойынша сұрыптауды басу",
	sortingState: "${0} - ${1}",
	unsorted: "Бұл бағанды сұрыптамау",
	indirectSelectionRadio: "${0} қатары, жалғыз таңдау, айырып-қосқыш",
	indirectSelectionCheckBox: "${0} қатары, бірнеше таңдау, құсбелгі",
	selectAll: "Барлығын таңдау"
})
);
