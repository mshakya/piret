define(
"dojox/grid/enhanced/nls/he/EnhancedGrid", ({
	singleSort: "מיון יחיד",
	nestedSort: "מיון מקונן",
	ascending: "לחצו כדי למיין בסדר עולה",
	descending: "לחצו כדי למיין בסדר יורד",
	sortingState: "${0} - ${1}",
	unsorted: "אין למיין עמודה זו",
	indirectSelectionRadio: "שורה ${0}, בחירה יחידה, תיבת בחירה",
	indirectSelectionCheckBox: "שורה ${0}, בחירה מרובה, תיבת סימון",
	selectAll: "בחירת הכל"
})
);
