define(
"dojox/grid/enhanced/nls/de/Pagination", ({
	"descTemplate": "${2} - ${3} von ${1} ${0}",
	"firstTip": "Erste Seite",
	"lastTip": "Letzte Seite",
	"nextTip": "Nächste Seite",
	"prevTip": "Vorherige Seite",
	"itemTitle": "Einträge",
	"singularItemTitle": "Eintrag",
	"pageStepLabelTemplate": "Seite ${0}",
	"pageSizeLabelTemplate": "${0} Einträge pro Seite",
	"allItemsLabelTemplate": "Alle Einträge",
	"gotoButtonTitle": "Wechsel zu einer bestimmten Seite",
	"dialogTitle": "Wechseln zur Seite",
	"dialogIndication": "Seitennummer angeben",
	"pageCountIndication": " (${0} Seiten)",
	"dialogConfirm": "Start",
	"dialogCancel": "Abbrechen",
	"all": "Alle"
})
);
