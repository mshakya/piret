define(
"dojox/grid/enhanced/nls/sk/EnhancedGrid", ({
	singleSort: "Jednoduché triedenie",
	nestedSort: "Vnorené triedenie",
	ascending: "Kliknite pre vzostupné triedenie",
	descending: "Kliknite pre zostupné triedenie",
	sortingState: "${0} - ${1}",
	unsorted: "Netriediť tento stĺpec",
	indirectSelectionRadio: "Riadok ${0}, jednoduchý výber, prepínač",
	indirectSelectionCheckBox: "Riadok ${0}, viacnásobný výber, začiarkavacie políčko",
	selectAll: "Vybrať všetko"
})
);
