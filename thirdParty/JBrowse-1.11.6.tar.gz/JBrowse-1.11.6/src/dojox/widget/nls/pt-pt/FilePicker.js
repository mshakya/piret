define(
"dojox/widget/nls/pt-pt/FilePicker", ({
	name: "Nome",
	path: "Caminho",
	size: "Tamanho (em bytes)"
})
);
