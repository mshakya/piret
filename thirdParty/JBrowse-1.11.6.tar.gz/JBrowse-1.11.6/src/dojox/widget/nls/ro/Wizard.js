define(
"dojox/widget/nls/ro/Wizard", ({
next: "Următor",
previous: "Anterior",
done: "Gata"
})
);
