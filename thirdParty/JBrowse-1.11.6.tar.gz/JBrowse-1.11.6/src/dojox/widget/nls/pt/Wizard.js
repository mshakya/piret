define(
"dojox/widget/nls/pt/Wizard", ({
next: "Próximo",
previous: "Anterior",
done: "Concluído"
})
);
