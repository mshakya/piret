define(
"dojox/widget/nls/fi/Wizard", ({
next: "Seuraava",
previous: "Edellinen",
done: "Valmis"
})
);
