define(
"dojox/widget/nls/he/FilePicker", ({
	name: "שם",
	path: "נתיב",
	size: "גודל (בבתים)"
})
);
