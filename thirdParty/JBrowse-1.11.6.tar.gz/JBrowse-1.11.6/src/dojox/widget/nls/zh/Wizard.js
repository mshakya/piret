define(
"dojox/widget/nls/zh/Wizard", ({
next: "下一个",
previous: "上一个",
done: "完成"
})
);
