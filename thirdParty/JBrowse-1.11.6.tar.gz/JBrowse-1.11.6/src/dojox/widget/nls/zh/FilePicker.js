define(
"dojox/widget/nls/zh/FilePicker", ({
	name: "名称",
	path: "路径",
	size: "大小（以字节计）"
})
);
