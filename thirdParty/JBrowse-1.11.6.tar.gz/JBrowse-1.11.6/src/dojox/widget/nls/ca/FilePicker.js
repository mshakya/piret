define(
"dojox/widget/nls/ca/FilePicker", ({
	name: "Nom",
	path: "Camí d'accés",
	size: "Mida (en bytes)"
})
);
