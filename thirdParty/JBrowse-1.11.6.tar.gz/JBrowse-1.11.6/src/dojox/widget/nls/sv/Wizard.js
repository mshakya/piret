define(
"dojox/widget/nls/sv/Wizard", ({
next: "Nästa",
previous: "Föregående",
done: "Klart"
})
);
