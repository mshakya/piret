define(
"dojox/widget/nls/sv/FilePicker", ({
	name: "Namn",
	path: "Sökväg",
	size: "Storlek (i byte)"
})
);
