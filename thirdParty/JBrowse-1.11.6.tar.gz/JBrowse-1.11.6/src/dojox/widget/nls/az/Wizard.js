define(
"dojox/widget/nls/az/Wizard", ({
	"next" : "Irəli",
	"done" : "Qurtardı",
	"previous" : "Geri"
})
);
