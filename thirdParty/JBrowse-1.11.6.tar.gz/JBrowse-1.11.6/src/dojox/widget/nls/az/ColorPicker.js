define(
"dojox/widget/nls/az/ColorPicker", ({
	"redLabel" : "q",
	"valueLabel" : "d",
	"hexLabel" : "onaltılıq",
	"hueLabel" : "ç",
	"saturationLabel" : "d",
	"greenLabel" : "y",
	"blueLabel" : "m",
	"saturationPickerTitle" : "Doldurmaq seçimi",
	"huePickerTitle" : "Çalar seçimi",
	"degLabel" : "°"
})
);
