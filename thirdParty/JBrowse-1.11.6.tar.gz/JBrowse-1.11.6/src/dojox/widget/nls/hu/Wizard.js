define(
"dojox/widget/nls/hu/Wizard", ({
next: "Tovább",
previous: "Előző",
done: "Kész"
})
);
