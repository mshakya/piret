define(
"dojox/widget/nls/tr/FilePicker", ({
	name: "Ad",
	path: "Yol",
	size: "Boyut (bayt cinsinden)"
})
);
