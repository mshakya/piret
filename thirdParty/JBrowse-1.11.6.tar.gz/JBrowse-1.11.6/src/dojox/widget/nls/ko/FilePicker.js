define(
"dojox/widget/nls/ko/FilePicker", ({
	name: "이름",
	path: "경로",
	size: "크기(바이트)"
})
);
