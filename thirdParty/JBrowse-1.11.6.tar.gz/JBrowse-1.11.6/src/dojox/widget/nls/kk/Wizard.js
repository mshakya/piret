define(
"dojox/widget/nls/kk/Wizard", ({
next: "Келесі",
previous: "Алдыңғы",
done: "Дайын"
})
);
