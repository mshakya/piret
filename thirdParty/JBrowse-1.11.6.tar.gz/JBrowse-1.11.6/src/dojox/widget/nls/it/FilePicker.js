define(
"dojox/widget/nls/it/FilePicker", ({
	name: "Nome",
	path: "Percorso",
	size: "Dimensione (in byte)"
})
);
