define(
"dojox/widget/nls/th/FilePicker", ({
	name: "ชื่อ",
	path: "พาธ",
	size: "ขนาด (เป็นไบต์)"
})
);
