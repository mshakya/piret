define(
"dojox/widget/nls/da/ColorPicker", ({
redLabel: "r",
greenLabel: "g",
blueLabel: "b",
hueLabel: "n",
saturationLabel: "m",
valueLabel: "v", /* aka intensity or brightness */
degLabel: "\u00B0",
hexLabel: "hex",
huePickerTitle: "Vælg nuance",
saturationPickerTitle: "Vælg mætning"
})
);
